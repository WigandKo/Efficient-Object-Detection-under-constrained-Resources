import sys
import os
import argparse
import numpy as np
from yolo import YOLO, detect_video
from PIL import Image
from tensorflow.python.framework.ops import disable_eager_execution

#input_folder_path = '../datasets/VOC2010/JPEGImages/'      #JPEG160x128_person
input_folder_path = '../datasets/VOC2012/Resized/JPEG288x288_test/'

output_folder_path = './results/'

def detect_img(yolo):
    while True:
        img = input('Input image filename:')
        try:
            image = Image.open(img)
        except:
            print('Open Error! Try again!')
            continue
        else:
            r_image = yolo.detect_image(image)
            r_image.show()
    yolo.close_session()

def process_images_in_folder(input_folder, output_folder, yolo, should_close = True):
    # Check if output folder exists, create it if not
    if not os.path.exists(output_folder):
        os.makedirs(output_folder)

    # List all files in the input folder
    image_files = [f for f in os.listdir(input_folder) if f.lower().endswith(('.png', '.jpg', '.jpeg', '.gif', '.bmp'))]

    for img_filename in image_files:
        img_path = os.path.join(input_folder, img_filename)

        try:
            image = Image.open(img_path)
        except:
            print(f'Error opening image: {img_path}')
            continue

        # Detect image using the yolo.detect_image method
        found_boxes = yolo.detect_image(image)

        # Create a file name for the output file based on the input image name
        output_filename = f"{os.path.splitext(img_filename)[0]}.txt"
        output_path = os.path.join(output_folder, output_filename)
        np.set_printoptions(suppress=True)
        # Save the detection results to the output file
        with open(output_path, 'w') as output_file:
            for label, score, left, right, top, bottom in found_boxes:
                #output_str = np.array2string(yolo_output, separator=', ', threshold=np.inf)
                output_file.write(f"{label} {score} {left} {right} {top} {bottom}\n")

        print(f"Results for {img_filename} saved to {output_filename}")
    if should_close:
        yolo.close_session()    

FLAGS = None

if __name__ == '__main__':
    # class YOLO defines the default value, so suppress any default here
    disable_eager_execution()
    parser = argparse.ArgumentParser(argument_default=argparse.SUPPRESS)
    '''
    Command line options
    '''
    parser.add_argument(
        '--model', type=str,
        help='path to model weight file, default ' + YOLO.get_defaults("model_path")
    )

    parser.add_argument(
        '--anchors', type=str,
        help='path to anchor definitions, default ' + YOLO.get_defaults("anchors_path")
    )

    parser.add_argument(
        '--classes', type=str,
        help='path to class definitions, default ' + YOLO.get_defaults("classes_path")
    )

    parser.add_argument(
        '--gpu_num', type=int,
        help='Number of GPU to use, default ' + str(YOLO.get_defaults("gpu_num"))
    )

    parser.add_argument(
        '--image', default=False, action="store_true",
        help='Image detection mode, will ignore all positional arguments'
    )
    '''
    Command line positional arguments -- for video detection mode
    '''
    parser.add_argument(
        "--input", nargs='?', type=str,required=False,default='./path2your_video',
        help = "Video input path"
    )

    parser.add_argument(
        "--output", nargs='?', type=str, default="",
        help = "[Optional] Video output path"
    )

    FLAGS = parser.parse_args()

    if FLAGS.image:
        """
        Image detection mode, disregard any remaining command line arguments
        """
        print("Image detection mode")
        if "input" in FLAGS:
            print(" Ignoring remaining command line arguments: " + FLAGS.input + "," + FLAGS.output)
        #detect_img(YOLO(**vars(FLAGS)))
        process_images_in_folder(input_folder_path, output_folder_path, YOLO(**vars(FLAGS)))
    elif "input" in FLAGS:
        detect_video(YOLO(**vars(FLAGS)), FLAGS.input, FLAGS.output)
    else:
        print("Must specify at least video_input_path.  See usage with --help.")
