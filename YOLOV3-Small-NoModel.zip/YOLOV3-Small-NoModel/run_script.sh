#!/bin/bash

# Define the parameters
params=(1 2 3 4 5 6 7 8 9 10)
# Loop through the parameters
for number in "${params[@]}"
do
    # Run the Python script with the current parameter
    python3 train.py $number
done
