"""
Retrain the YOLO model for your own dataset.
"""
import sys
import numpy as np
#import keras.backend as K
import tensorflow.python.keras.backend as K
import tensorflow as tf
from keras.layers import Input, Lambda
from keras.models import Model
from keras.optimizers import Adam, SGD
from keras.callbacks import TensorBoard, ModelCheckpoint, ReduceLROnPlateau, EarlyStopping

from yolo3.model import preprocess_true_boxes, yolo_body, yolo_loss, mobilenet_yolo
from yolo3.utils import get_random_data, get_data, get_fixed_data, get_flipped_data

from keras.utils import plot_model
from yolo_video import process_images_in_folder
import os 
from yolo import YOLO
from mAP.main import calculate_mAP
from TrainingMetricsLogger import TrainMetricLogger

from tensorflow.python.framework.ops import disable_eager_execution
import tensorflow_model_optimization as tfmot

#Trained models for the thesis, models are named in the files
from yolo3.mbv2_final import mbv2_dh, mbv2_tinydh, mbv2tiny_scaled_tinydh, mbv2tiny_manual_tinydh, mbv2tiny_manual_tinydh288, mbv2tiny_manual_tinydh288, mbv2tiny_latency_tinydh192, mbv2tiny_manual_tinydh192
from yolo3.mcu_final import mcu_tinydh, mcu_smalldh224, mcu_smalldh192, mcu_latency_smalldh192


#Set the input Resolution
input_shape = (224,224) # multiple of 32, hw # 128 160

#Quantize aware trainig
quantize_model = False

#Documentation ID
test_id = 'test1'#

#Number of epochs
used_epochs = 600

#Continue Training if blank you start from scratch
pre_trained = "" 


#pass the function that returns the model to be trained
def _main(model_function):
    annotation_path = 'train_' + str(input_shape[0]) + 'x' + str(input_shape[1]) + '_2012_train.txt'
    print(annotation_path)
    log_dir = 'logs/' + test_id + "/"
    classes_path = 'model_data/voc_classes.txt'
    anchors_path = 'model_data/yolo_anchors.txt'
    class_names = get_classes(classes_path)
    num_classes = len(class_names)
    anchors = get_anchors(anchors_path)
    

    #Creates model
    model = create_tiny_model(input_shape, anchors, num_classes, weights_path=pre_trained, model_function=model_function)
        

    model.summary()

    training_metrics_logger = TrainMetricLogger(log_dir + "training_metrics.txt")
    logging = TensorBoard(log_dir=log_dir)
    model_checkpoint = ModelCheckpoint(log_dir + 'ep{epoch:03d}-loss{loss:.3f}-val_loss{val_loss:.3f}.h5',
        monitor='val_loss', save_weights_only=True, save_best_only=True) #, period=3
    reduce_lr = ReduceLROnPlateau(monitor='val_loss', factor=0.1, patience=15, verbose=1) #15
    early_stopping = EarlyStopping(monitor='val_loss', min_delta=0, patience=30, verbose=1) # 30

    val_split = 0.1
    with open(annotation_path) as f:
        lines = f.readlines()
    np.random.seed(10101)
    np.random.shuffle(lines)
    np.random.seed(None)
    num_val = int(len(lines)*val_split)
    num_train = len(lines) - num_val

    model.compile(optimizer=Adam(), loss={'yolo_loss': lambda y_true, y_pred: y_pred}) # recompile to apply the change

    batch_size = 32 # note that more GPU memory is required after unfreezing the body
    print('Train on {} samples, val on {} samples, with batch size {}.'.format(num_train, num_val, batch_size))
    #fit_generator
    model.fit(data_generator_wrapper(lines[:num_train], batch_size, input_shape, anchors, num_classes),
        steps_per_epoch=max(1, num_train//batch_size),
        validation_data=data_generator_wrapper(lines[num_train:], batch_size, input_shape, anchors, num_classes),
        validation_steps=max(1, num_val//batch_size),
        epochs=used_epochs,#100
        initial_epoch=0,#50
        callbacks=[logging, model_checkpoint, reduce_lr, early_stopping, training_metrics_logger])
    #model.save_weights(log_dir + 'trained_mini_weights_final.h5')#saved as tensorflow checkpoint
    model.save(log_dir + 'model.h5')


    #Quantized Model
    output_1 = model.get_layer("y1").output
    output_2 = model.get_layer("y2").output
    output_3 = model.get_layer("y3").output        
    if quantize_model:
        output_1 = model.get_layer("quant_y1").output
        output_2 = model.get_layer("quant_y2").output
        output_3 = model.get_layer("quant_y3").output

    # Create a new model without the last Lambda layer        
    model_new = Model(inputs=model.input[0], outputs=[output_1, output_2, output_3]) # small to large    print(model_new.summary())
    model_new.save(log_dir + 'yolo_model.h5')

    # Convert the Keras model to TFLite format
    converter = tf.lite.TFLiteConverter.from_keras_model(model_new)
    converter.optimizations = [tf.lite.Optimize.DEFAULT]

    tflite_model = converter.convert()

    # Save the TFLite model to a file
    with open("tfmot_quantized_model.tflite", "wb") as f:
        f.write(tflite_model)

    checkpoint = tf.train.Checkpoint(model)
    # Save a checkpoint to /tmp/training_checkpoints-{save_counter}. Every time
    # checkpoint.save is called, the save counter is increased.
    checkpoint.save('/tmp/training_checkpoints')


    #Gets the best Model checkpoint
    best_weights_file = get_best_val_loss_model(log_dir)

    #Evaluates the model
    run_yolo_on(best_weights_file, model_function)


def get_classes(classes_path):
    '''loads the classes'''
    with open(classes_path) as f:
        class_names = f.readlines()
    class_names = [c.strip() for c in class_names]
    return class_names

def get_anchors(anchors_path):
    '''loads the anchors from a file'''
    with open(anchors_path) as f:
        anchors = f.readline()
    anchors = [float(x) for x in anchors.split(',')]
    return np.array(anchors).reshape(-1, 2)
    
#creates the model
def create_tiny_model(input_shape, anchors, num_classes,
            weights_path, model_function):
    '''create the training model, for Tiny YOLOv3'''
    K.clear_session() # get a new session
    image_input = Input(shape=(input_shape[0], input_shape[1], 3))
    h, w = input_shape
    num_anchors = len(anchors)


    # Sets the anchors
    y_true = [Input(shape=(h//{0:32, 1:16, 2:8}[l], w//{0:32, 1:16, 2:8}[l], \
        num_anchors//3, num_classes+5)) for l in range(3)]


    # Calls the passed model function of main with the configured parameters
    model_body = model_function(image_input, num_classes)

    #Quantization
    print('Create Tiny YOLOv3 model with {} anchors and {} classes.'.format(num_anchors, num_classes))
    if quantize_model:
        model_body = tfmot.quantization.keras.quantize_model(model_body)

    #Continue training option
    if weights_path != "":
        model_body.load_weights(weights_path, by_name=True, skip_mismatch=True)
        print('Load weights {}.'.format(weights_path))


    #Adds lambda layer to the model
    model_loss = Lambda(yolo_loss, output_shape=(1,), name='yolo_loss',
        arguments={'anchors': anchors, 'num_classes': num_classes, 'ignore_thresh': 0.5})(
        [*model_body.output, *y_true])
    model = Model([model_body.input, *y_true], model_loss)
    return model

def data_generator(annotation_lines, batch_size, input_shape, anchors, num_classes):
    '''data generator for fit_generator'''
    n = len(annotation_lines)
    i = 0
    while True:
        image_data = []
        box_data = []
        for b in range(batch_size):
            if i==0:
                np.random.shuffle(annotation_lines)
            #image, box = get_random_data(annotation_lines[i], input_shape, random=False) #Damit liefs    # first .1 .05 1.1 1.1 ## .25 .15 1.2 1.2
            image, box = get_random_data(annotation_lines[i], input_shape, random=True, max_boxes=20, jitter=.00, hue=.0, sat=1.0, val=1.0, proc_img=True)
            #image, box = get_flipped_data(annotation_lines[i], input_shape)
            #image, box = get_data(annotation_lines[i], input_shape)
            image_data.append(image)
            box_data.append(box)
            i = (i+1) % n
        image_data = np.array(image_data)
        box_data = np.array(box_data)
        y_true = preprocess_true_boxes(box_data, input_shape, anchors, num_classes)
        yield [image_data, *y_true], np.zeros(batch_size)

def data_generator_wrapper(annotation_lines, batch_size, input_shape, anchors, num_classes):
    n = len(annotation_lines)
    if n==0 or batch_size<=0: return None
    return data_generator(annotation_lines, batch_size, input_shape, anchors, num_classes)

def run_yolo_on(model_name, model_function):
    input_inference_folder = '../datasets/VOC2012/Resized/JPEG'+ \
        str(input_shape[0]) + "x" + str(input_shape[1])
    ground_truth_folder = "ground-truth-2012-" + str(input_shape[0]) + "x" + str(input_shape[1])
    disable_eager_execution()
    yolo = YOLO(model_function = model_function, quantize_model = quantize_model, model_image_size = input_shape, model_path="logs/"+test_id+"/"+model_name+".h5", anchors_path="model_data/yolo_anchors.txt", classes_path="model_data/voc_classes.txt")
    mAP_input_path = "mAP/input/"
    
    result_test = "results_" + test_id + "_test"
    result_complete = "results_" + test_id + "_complete"

    os.makedirs(mAP_input_path + result_test, exist_ok=True)
    os.makedirs(mAP_input_path + result_complete, exist_ok=True)

    output_test = "output_" + test_id + "_test"
    output_complete = "output_" + test_id + "_complete"

    # Save the original working directory
    original_dir = os.getcwd()
                                                                                         
    #process data of complete dataset
    process_images_in_folder(input_inference_folder+ "/", mAP_input_path + result_complete, yolo, should_close=False)
    calculate_mAP(ground_truth_folder,result_complete, output_complete)
    os.chdir(os.path.dirname(os.path.abspath(__file__)))

   #process data of test dataset
    process_images_in_folder(input_inference_folder+"_test/", mAP_input_path + result_test, yolo, should_close=True)
    calculate_mAP(ground_truth_folder + "_test", result_test, output_test)

    os.chdir(os.path.dirname(os.path.abspath(__file__)))

def get_best_val_loss_model(directory):
    h5_files = [file for file in os.listdir(directory) if file.endswith('.h5') and 'val_loss' in file]
    best_val_loss = float('inf')
    best_model_file = None
    
    for h5_file in h5_files:
        val_loss = float(h5_file.split('-')[-1].split('.h5')[0].split('val_loss')[1])
        
        if val_loss < best_val_loss:
            best_model_file = h5_file
            best_val_loss = val_loss
    
    return best_model_file[:-3]

if __name__ == '__main__':


    input_shape = (192,192)
    quantize_model = False
    test_id = 'mcu_latency_smalldh192'#
    used_epochs = 600
    pre_trained = ""
    _main(mcu_latency_smalldh192)