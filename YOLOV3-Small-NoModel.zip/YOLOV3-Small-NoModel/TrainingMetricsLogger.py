import time
from keras.callbacks import Callback

class TrainMetricLogger(Callback):
    def __init__(self, log_file):
        super(TrainMetricLogger, self).__init__()
        self.log_file = log_file

    def on_train_begin(self, logs=None):
        self.start_time = time.time()

    def on_train_end(self, logs=None):
        end_time = time.time()
        total_time = end_time - self.start_time

        with open(self.log_file, 'a') as f:
            f.write('Training Metrics:\n')
            f.write('Total Training Time: {:.2f} seconds\n'.format(total_time))
            f.write('Validation Loss: {:.4f}\n'.format(logs['val_loss']))
            f.write('Epochs: {}\n'.format(len(self.model.history.history['loss'])))
            f.write('Total Model Parameters: {}\n'.format(self.model.count_params()))
